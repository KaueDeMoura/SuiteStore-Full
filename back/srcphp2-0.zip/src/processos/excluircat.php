<?php

    if(!empty($_GET['id']))
    {
        include_once '../conexao.php';

        $id = $_GET['id'];

        $sqlSelect = "SELECT *  FROM public.categorias WHERE id=$id";

        $result = $myPDO->query($sqlSelect);

            $sqlDelete = "DELETE FROM public.categorias WHERE id=$id";
            $resultDelete = $myPDO->query($sqlDelete);

            header("Location: ../pages/categorias.php");
     
    }else{
        echo "Erro ao excluir categoria selecionada";
    }
?>