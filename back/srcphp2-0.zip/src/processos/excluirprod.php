<?php

    if(!empty($_GET['id']))
    {
        include_once '../conexao.php';

        $id = $_GET['id'];

        $sqlSelect = "SELECT *  FROM public.produtos WHERE id=$id";

        $result = $myPDO->query($sqlSelect);

            $sqlDelete = "DELETE FROM public.produtos WHERE id=$id";
            $resultDelete = $myPDO->query($sqlDelete);

            header("Location: ../pages/produtos.php");
           exit;
    }else{
        echo "Erro ao excluir produto selecionado";
    }
?>