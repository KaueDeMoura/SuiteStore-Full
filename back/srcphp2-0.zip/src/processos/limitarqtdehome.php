<?php
/*
setar uma variavel com valor 
ao escoler um produto no home aqui devera puxar com um select ou algo assim a QUANTIDADE que tem do PRODUTO e 
fazer um if que será a primeira coisa a rodar
após clicar no botao adicionar produto do home
if(Quantidade-Selecionada-Input-Home > $QuantidadeEstoqueProduto){
    echo "<script>alert(Quantidade maxima permitida é $QuantidadeEstoqueProduto)</script>"
}
    toda vez que selecionar um produto a variavel ira mudar
*/

echo "testeeee";
?>