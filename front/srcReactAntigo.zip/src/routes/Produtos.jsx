import styles from '../css/Produtos.module.css';

function Produtos() {

return (

<div>
<body>
  <div className={styles.pagina}>

    <div className={styles.separar}>
      <form action="produtos.php" method="POST" id="formProduto">
        <br />
        <input type="text" name="produto" placeholder="Nome do Produto" id="inputProduto" className={styles.inputcs}
          required />
        <input type="number" name="quantidade" placeholder="Quantidade" id="inputQuantidade" required />
        <input type="text" name="preco" placeholder="Preço da unidade" id="inputPreco" className={styles.taxacs} required />
        <br />
        <select name="selectCategoria" id="Categoria" method="POST" action="produtos.php" required>
          
          <option value="" disabled selected>Categoria</option>
          
            <option value="<?php echo $option['nomecat']?>">
              </option>
        </select>
        <p className={styles.errorMsg}>Por favor, insira informações válidas!</p>
        <button type="submit">Adicionar produto</button>
        <p></p>
      </form>
    </div>

    <div className={styles.divisao}></div>
    <div className={styles.separar}>
      <div className={styles.tabela}>
        <table>
          <tr>
            <th>Código</th>
            <th>Produto</th>
            <th>Quantidade</th>
            <th>Preço unidade</th>
            <th>Categoria</th>
            <th>Ação</th>
          </tr>
          <tbody id="listaProdutosBody"></tbody>
        </table>
      </div>
    </div>
  </div>
  </body>
</div>

)

}

export default Produtos;