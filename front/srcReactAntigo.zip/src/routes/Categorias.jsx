import styles from '../css/Categorias.module.css';

function Categorias() {

return (

<div>
    <body>
    <div className={styles.pagina}>
        <div className={styles.separar}>
        <form id="formCategoria">
            <input type="text" name="categoria" placeholder="Nome da Categoria (Apenas Letras)" id="inputCategoria" className={styles.qtde} />
            <input type="text" name="Taxa" placeholder="Taxa (Max 100%)" id="inputTaxa" className={styles.taxa} />
            <br />
            <button className={styles.inputBtn} type="submit" id="cadastrar" value="Adcicionar">
            Adicionar Categoria
            </button>
            <p></p>
        </form>
        </div>

        <div className={styles.divisao}></div>
        <div className={styles.separar}>
        <div className={styles.tabela}>
            <table id="tabelaCategorias">
            <tr>
                <th>Código</th>
                <th>Categoria</th>
                <th>Taxa (%)</th>
                <th>Ação</th>
            </tr>
            <tbody id="listaCategoriasBody"></tbody>
            </table>
        </div>
        </div>
    </div>
    <hr />

    <script src="../js/categorias.js"></script>
    </body>
</div>

)

}

export default Categorias;