import styles from '../css/Historico.module.css';

function Historico() {

return (

<div>
   <body>
   <div className={styles.pagina}>
      <div className={styles.separar1}>
         <div className={styles.carrt}>
         <h1>Historico</h1>
         </div>
         <div className={styles.tabela}>
            <table>
               <thead>
                  <tr>
                     <th className={styles.thid}>ID</th>
                     <th className={styles.thdata}>Data</th>
                     <th className={styles.thtotal}>Total</th>
                     <th className={styles.thacao}>Ação</th>
                  </tr>
               </thead>
               <tbody id="listaHistoricoBody"></tbody>
            </table>
         </div>
      </div>
      <div className={styles.divisao}></div>
      <div className={styles.sumir}>
         <div className={styles.separar2}>
            <h1>Detalhes da Compra</h1>
            <div className={styles.tabela}>
               <table id="tableHist">
                  <thead>
                     <tr>
                        <th className={styles.thproduto}>Produto</th>
                        <th className={styles.thpreco}>Preço Unidade</th>
                        <th className={styles.thquantidade}>Quantidade</th>
                        <th className={styles.thtaxa}>Taxa(%)</th>
                        <th className={styles.thtotal}>Total</th>
                     </tr>
                  </thead>
                  <tbody id="listaNovoDetalhesBody">
            </tbody>

               </table>

               <div className={styles.infos}>
                  <label for="inputTaxaTotal">Taxa Total:</label>
                  <input type="text" id="inputTaxaTotal" name="taxa" value="R$00.00" className={styles.inputTaxaTotal} readonly />
                  <br />
                  <label for="inputNovoValorTotal">Valor Total:</label>
                  <input type="text" id="inputNovoValorTotal" name="total" value="R$00,00" className={styles.inputValorTotal} readonly />
                  <br />

                  </div>
            </div>
         </div>
      </div>
      </div>
   <hr />
  </body>
</div>

)

}

export default Historico;