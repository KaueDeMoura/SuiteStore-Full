import styles from '../css/Home.module.css';

function Home() {

return (

<div>
<body>
  <div className={styles.pagina}>
    <div className={styles.separar}>
      <div className={styles.carrt}>
      <h1>Selecionar Produtos</h1>
      </div>
      <form id="formHome" action="index.php" method="POST" className={styles.input}>
      <select name="selectProduto" id="selectProduto" method="POST" action="index.php" className={styles.selectProduto} required>
          <option value="" disabled selected>Produto</option>
        </select>
        <br />
        <input type="number" name="Quantidade" placeholder="Quantidade" id="inputQuantidade" className={styles.qtde} required />

          <input type="number" name="Taxa" placeholder="Taxa" id="Taxa" readonly />
          <input type="text" name="Precound" placeholder="Preco" id="Preco" readonly/>

        <br />
        <p className={styles.errorMsg}>Por favor insira uma Quantidade Valida</p>
        <button className={styles.addProduto} id="addProduto" name="addProduto">Adcicionar produto</button>
        <p></p>
      </form>
    </div>


    <div className={styles.divisao}></div>

    <div className={styles.separar}>
      <div className={styles.carrt}>
      <h1>Carrinho</h1>
      </div>
      <div className={styles.tabela}>
        <table>
          <tr>
            <th>Produto</th>
            <th>Preço unidade</th>
              <th>Quantidade</th>
              <th>Total</th>
              <th>Ação</th>
            </tr>
            <tbody id="listaHomeBody"></tbody>
            
          </table>
          <div className={styles.infos}>
            <label>Taxa:</label>
            <input type="text" id="inputTaxaTotal" name="taxa" value="R$00.00" className={styles.inputTaxaTotal} readonly />
            <br />
            <label>Total:</label>
            <input type="text" id="inputValorTotal" name="total" value="R$00,00" className={styles.inputValorTotal} readonly />
            <br />

            <a href='./processos/inserthistorico.php?cancelar=cancelar' className={styles.cancelar}>Cancelar</a>
            <a href='./processos/inserthistorico.php?concluir=concluir' className={styles.concluir}>Concluir</a>
            
          </div>
        </div>
    </div>
  </div>
  <script src="./js/taxa.js"></script>
  <script src="./js/preco.js"></script>
  <hr />

  </body>
</div>

)

}

export default Home;