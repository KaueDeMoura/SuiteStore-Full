import { Link } from "react-router-dom";
import styles from '../css/Navbar.module.css';

const Navbar = () => {
    return(
        <nav>
            <Link to="/" className={styles.home}>Suite Store</Link> {/* className={styles.header} */}
            <Link to="/">Home</Link> {/* className={styles.cor} */}
            <Link to="/produtos">Produtos</Link>
            <Link to="/categorias">Categorias</Link>
            <Link to="/historico">Historico</Link>
        </nav>
    )
}

export default Navbar;